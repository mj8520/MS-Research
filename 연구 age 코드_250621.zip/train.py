from __future__ import division
from __future__ import print_function
import os, sys
import warnings
warnings.simplefilter(action='ignore', category=FutureWarning)
warnings.simplefilter(action='ignore', category=RuntimeWarning)
warnings.simplefilter(action='ignore', category=UserWarning)
sys.path.append(os.path.join(os.path.dirname(os.path.realpath(__file__)), os.pardir))
# For replicating the experiments
SEED = 42
import argparse
import time
import random
import numpy as np
import scipy.sparse as sp
import torch

np.random.seed(SEED)
torch.manual_seed(SEED)
from torch import optim
import torch.nn.functional as F
from model import LinTrans, LogReg
from optimizer import loss_function
from utils import *
from sklearn.cluster import SpectralClustering, KMeans
from clustering_metric import clustering_metrics
from tqdm import tqdm
from sklearn.preprocessing import normalize, MinMaxScaler
from sklearn import metrics
import matplotlib.pyplot as plt

parser = argparse.ArgumentParser()
parser.add_argument('--gnnlayers', type=int, default=3, help="Number of gnn layers")
parser.add_argument('--linlayers', type=int, default=1, help="Number of hidden layers")
parser.add_argument('--epochs', type=int, default=400, help='Number of epochs to train.')
parser.add_argument('--dims', type=int, default=[500], help='Number of units in hidden layer 1.')
parser.add_argument('--lr', type=float, default=0.001, help='Initial learning rate.')
parser.add_argument('--upth_st', type=float, default=0.0015, help='Upper Threshold start.') # 상위 0.15%
parser.add_argument('--lowth_st', type=float, default=0.1, help='Lower Threshold start.') # 하위 100% 
parser.add_argument('--upth_ed', type=float, default=0.001, help='Upper Threshold end.') # 상위 0.1%
parser.add_argument('--lowth_ed', type=float, default=0.5, help='Lower Threshold end.') # 하위 50%  
parser.add_argument('--upd', type=int, default=10, help='Update epoch.')
parser.add_argument('--bs', type=int, default=10000, help='Batchsize.')
parser.add_argument('--dataset', type=str, default='citeseer', help='type of dataset.')
parser.add_argument('--no-cuda', action='store_true', default=False,
                    help='Disables CUDA training.')
args = parser.parse_args()
args.cuda = not args.no_cuda and torch.cuda.is_available()

if args.cuda is True:
    print('Using GPU')
    torch.cuda.manual_seed(SEED)
    os.environ["CUDA_VISIBLE_DEVICES"] = "5"



def clustering(Cluster, feature, true_labels):
    f_adj = np.matmul(feature, np.transpose(feature)) # feature matrix (X) 로 X @ X.T 계산 
    predict_labels = Cluster.fit_predict(f_adj)
    
    cm = clustering_metrics(true_labels, predict_labels)
    db = -metrics.davies_bouldin_score(f_adj, predict_labels)
    acc, nmi, adj = cm.evaluationClusterModelFromLabel(tqdm)

    return db, nmi, adjscore, acc, f1_macro, precision_macro, recall_macro


def update_similarity_1(f_adj, upper_threshold, lower_treshold, pos_num, neg_num):
    cosine = f_adj 
    cosine = cosine.reshape([-1,]) # 벡터 형태로 변환 
    pos_num = round(upper_threshold * len(cosine)) # 상위 upper_threshold% 만큼 양성 샘플 개수 
    neg_num = round((1-lower_treshold) * len(cosine)) # 하위 lower_treshold% 만큼 음성 샘플 개수 
    
    pos_inds = np.argpartition(-cosine, pos_num)[:pos_num] # 가장 큰 값 pos_num개 선택 (양성 샘플)
    neg_inds = np.argpartition(cosine, neg_num)[:neg_num] # 가장 작은 값 neg_num개 선택 (음성 샘플) 
    
    return np.array(pos_inds), np.array(neg_inds)

def update_similarity(z, upper_threshold, lower_treshold, pos_num, neg_num):
    f_adj = np.matmul(z, np.transpose(z)) # 유사도 행렬 생성 
    cosine = f_adj 
    cosine = cosine.reshape([-1,]) # 벡터 형태로 변환 
    pos_num = round(upper_threshold * len(cosine)) # 상위 upper_threshold% 만큼 양성 샘플 개수 
    neg_num = round((1-lower_treshold) * len(cosine)) # 하위 lower_treshold% 만큼 음성 샘플 개수 
    
    pos_inds = np.argpartition(-cosine, pos_num)[:pos_num] # 가장 큰 값 pos_num개 선택 (양성 샘플)
    neg_inds = np.argpartition(cosine, neg_num)[:neg_num] # 가장 작은 값 neg_num개 선택 (음성 샘플) 
    
    return np.array(pos_inds), np.array(neg_inds)
    

def update_threshold(upper_threshold, lower_treshold, up_eta, low_eta): # 임계값 업데이트 
    upth = upper_threshold + up_eta 
    lowth = lower_treshold + low_eta
    return upth, lowth




def gae_for(args):
    print("Using {} dataset".format(args.dataset))
    if args.dataset == 'cora':
        n_clusters = 7
        Cluster = SpectralClustering(n_clusters=n_clusters, affinity = 'precomputed', random_state=0)
    elif args.dataset == 'citeseer':
        n_clusters = 6
        Cluster = SpectralClustering(n_clusters=n_clusters, affinity = 'precomputed', random_state=0)
    elif args.dataset == 'pubmed':
        n_clusters = 3
        Cluster = SpectralClustering(n_clusters=n_clusters, affinity = 'precomputed', random_state=0)
    elif args.dataset == 'wiki':
        n_clusters = 17
        Cluster = SpectralClustering(n_clusters=n_clusters, affinity = 'precomputed', random_state=0)
    
    adj, features, true_labels, idx_train, idx_val, idx_test = load_data(args.dataset) 
    n_nodes, feat_dim = features.shape # feature matrix 차원 (n*T)
    dims = [feat_dim] + args.dims # 모델의 입력 차원 
    
    layers = args.linlayers
    # Store original adjacency matrix (without diagonal entries) for later
    
    adj = adj - sp.dia_matrix((adj.diagonal()[np.newaxis, :], [0]), shape=adj.shape) # self-loop 제거 
    adj.eliminate_zeros() # 메모리 최적화를 위해 0 원소 제거 

    #adj_train, train_edges, val_edges, val_edges_false, test_edges, test_edges_false = mask_test_edges(adj)
    
    n = adj.shape[0]

    adj_norm_s = preprocess_graph(adj, args.gnnlayers, norm='sym', renorm=True) # 라플라시안 필터 행렬 (adj_norm_s) 생성됨 
    sm_fea_s = sp.csr_matrix(features).toarray() # crs_matrix : 희소 행렬로 변환 , toarray : 밀집 행렬로 변환 (라플라시안 연산 수행위해)
    
    print('Laplacian Smoothing...')
    for a in adj_norm_s:
        sm_fea_s = a.dot(sm_fea_s) # 라플라시안 행렬 (adj_norm_s)을 특징 행렬 sm_fea_s에 곱 => X 틸다 계산 
    adj_1st = (adj + sp.eye(n)).toarray() # 자기루프가 추가된 인접행렬 생성 

    db, best_acc, best_nmi, best_adj = clustering(Cluster, sm_fea_s, true_labels) # db : 클러스터링 품질 평가 

    best_cl = db # 인코딩 없이 스무딩된 X 틸다로 클러스터링 
    adj_label = torch.FloatTensor(adj_1st) 
    
    model = LinTrans(layers, dims)
    
    optimizer = optim.Adam(model.parameters(), lr=args.lr)
    
    sm_fea_s = torch.FloatTensor(sm_fea_s)
    adj_label = adj_label.reshape([-1,])

    if args.cuda:
        model.cuda()
        inx = sm_fea_s.cuda()
        adj_label = adj_label.cuda()

    pos_num = len(adj.indices) # 양수 샘플 개수 정의 
    neg_num = n_nodes*n_nodes-pos_num # 음수 샘플 개수 정의 

    up_eta = (args.upth_ed - args.upth_st) / (args.epochs/args.upd) # 몇 번의 업데이트에서 변화(eta)를 적용할 것인지 계산
    low_eta = (args.lowth_ed - args.lowth_st) / (args.epochs/args.upd) # 몇 번의 업데이트에서 변화(eta)를 적용할 것인지 계산

    #처음엔 인접행렬에서 pos_num , neg_num 정의 
    pos_inds, neg_inds = update_similarity(normalize(sm_fea_s.numpy()), args.upth_st, args.lowth_st, pos_num, neg_num) 
    upth, lowth = update_threshold(args.upth_st, args.lowth_st, up_eta, low_eta) # 임계값 업데이트 

    bs = min(args.bs, len(pos_inds)) # 배치 사이즈 : bs
    length = len(pos_inds)
    
    pos_inds_cuda = torch.LongTensor(pos_inds).cuda()
    print('Start Training...')
    for epoch in tqdm(range(args.epochs)):
        
        st, ed = 0, bs # bs가 len(pos_inds) ed 
        batch_num = 0
        model.train()
        length = len(pos_inds)
        
        while ( ed <= length ): # 배치 사이즈가 pos 길이보다 작거나 같은 동안 
            sampled_neg = torch.LongTensor(np.random.choice(neg_inds, size=ed-st)).cuda() # neg_inds에서 ed-st 크기 랜덤 샘플하여 sampled_neg 
            sampled_inds = torch.cat((pos_inds_cuda[st:ed], sampled_neg), 0) # 현재 배치에서 생성된 양성 샘플과 음성 샘플 합체 
            t = time.time()
            optimizer.zero_grad() # 그래디언트 초기화 
            xind = sampled_inds // n_nodes
            yind = sampled_inds % n_nodes
            x = torch.index_select(inx, 0, xind) # 샘플링된 노드 쌍에서 첫번째 노드의 인덱스 추출 
            y = torch.index_select(inx, 0, yind) # 샘플링된 노드 쌍에서 두번째 노드의 인덱스 추출  - 각각의 노드 feature가 됨 
            zx = model(x) # 모델을 거친 후의 노드 임베딩 
            zy = model(y) # 모델을 거친 후의 노드 임베딩 
            batch_label = torch.cat((torch.ones(ed-st), torch.zeros(ed-st))).cuda() # 라벨 생성 
            batch_pred = model.dcs(zx, zy) #  두 노드 간 유사도 계산 (link_pred) 
            loss = loss_function(adj_preds=batch_pred, adj_labels=batch_label, n_nodes=ed-st) # 예측한 링크 확률과 실제 정답 간 차이, 최소화하도록 모델 학습 
            
            loss.backward() # 손실 기반 그래디언트 계산 
            cur_loss = loss.item() # 현재 배치의 손실값 저장 
            optimizer.step() # 모델 가중치 업데이트 
            
            st = ed # 다음 배치 시작 위치 업데이트 
            batch_num += 1
            if ed < length and ed + bs >= length: 
                ed += length - ed
            else:
                ed += bs

            
        if (epoch + 1) % args.upd == 0: # 매 10 에폭마다 
            model.eval() # 평가 모델로 전환 
            mu = model(inx) # 전체 노드 임베딩 생성 
            hidden_emb = mu.cpu().data.numpy()
            upth, lowth = update_threshold(upth, lowth, up_eta, low_eta) # 양성/음성 샘플 선정을 위한 상하위 % 결정 
            pos_inds, neg_inds = update_similarity(hidden_emb, upth, lowth, pos_num, neg_num) #최신 임베딩 기반으로 새로운 양/음 샘플링 수행 
            bs = min(args.bs, len(pos_inds)) 
            pos_inds_cuda = torch.LongTensor(pos_inds).cuda()
            
            tqdm.write("Epoch: {}, train_loss_gae={:.5f}, time={:.5f}".format(
                epoch + 1, cur_loss, time.time() - t))
            
            db, acc, nmi, adjscore = clustering(Cluster, hidden_emb, true_labels)
            
            if db >= best_cl:
                best_cl = db
                best_acc = acc
                best_nmi = nmi
                best_adj = adjscore
            
        
    tqdm.write("Optimization Finished!")
    tqdm.write('best_acc: {}, best_nmi: {}, best_adj: {}'.format(best_acc, best_nmi, best_adj))
    

if __name__ == '__main__':
    gae_for(args)