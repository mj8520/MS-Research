import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.nn.modules.module import Module
from torch.nn.parameter import Parameter
import numpy as np

class GraphConvolution(Module): 
    """
    Simple GCN layer, similar to https://arxiv.org/abs/1609.02907
    """

    def __init__(self, in_features, out_features, dropout=0., act=F.relu):
        super(GraphConvolution, self).__init__()
        self.in_features = in_features # 입력 차원 (노드 특징 개수)
        self.out_features = out_features # 출력 차원 (임베딩 차원) 
        self.dropout = dropout # 드롭아웃 확률 
        self.act = act # 활성화 함수 (기본값 : ReLU) 
        self.weight = Parameter(torch.FloatTensor(in_features, out_features)) # 가중치 행렬 정의 : 입력 크기(in_features) * 출력 크기(out_features)  
        self.reset_parameters() # 가중치 초기화  

    def reset_parameters(self):
        torch.nn.init.xavier_uniform_(self.weight) # 가중치 초기화 

    def forward(self, input, adj): # 순전파 
        input = F.dropout(input, self.dropout, self.training) # 학습 시 드롭아웃 적용 
        support = torch.mm(input, self.weight) # 노드 특징 X와 가중치 행렬 W의 곱 
        output = torch.spmm(adj, support) # 인접행렬과 곱하여 이웃노드 정보 반영 
        output = self.act(output) #활성화 함수 사용 
        return output

    def __repr__(self): #GraphConvolution(128 -> 64) 이런 식으로 표시됨.
        return self.__class__.__name__ + ' (' \
               + str(self.in_features) + ' -> ' \
               + str(self.out_features) + ')'

class SampleDecoder(Module): # 디코더, 노드임베딩을 기반으로 연결 관계 예측 
    def __init__(self, act=torch.sigmoid):
        super(SampleDecoder, self).__init__()
        self.act = act

    def forward(self, zx, zy):
        sim = (zx * zy).sum(1) # 두 노드의 내적으로 유사도 측정 (S) 
        sim = self.act(sim) # 활성화 함수를 
    
        return sim