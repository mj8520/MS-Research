import torch
import torch.nn as nn
import torch.nn.functional as F

from layers import *

class LinTrans(nn.Module):
    def __init__(self, layers, dims): # layers : 사용할 레이어 개수 (1개) , dims : 각 레이어의 차원 리스트 (500)
        super(LinTrans, self).__init__()
        self.layers = nn.ModuleList()  # 빈 리스트 정의 
        for i in range(layers):
            self.layers.append(nn.Linear(dims[i], dims[i+1])) # 입력차원이 T, 출력차원이 500이 됨 
        self.dcs = SampleDecoder(act=lambda x: x) # 이전 코드에서 설정한 활성함수 그대로 

    def scale(self, z): # 스케일링 실시 (기울기 소실 문제로 값을 작은 범위로 조정하는 것이 유리) 
        
        zmax = z.max(dim=1, keepdim=True)[0]
        zmin = z.min(dim=1, keepdim=True)[0]
        z_std = (z - zmin) / (zmax - zmin)
        z_scaled = z_std
    
        return z_scaled

    def forward(self, x): # 순전파 
        out = x
        for layer in self.layers:
            out = layer(out)
        out = self.scale(out)
        out = F.normalize(out)
        return out


    def loss(self, x_hat, x, beta, rho):
        loss = F.mse_loss(x_hat, x) 
        return loss

class LogReg(nn.Module): # 다중 클래스 분류기 
    def __init__(self, ft_in, nb_classes): # ft_in : 입력 특징 차원 , nb_classes : 클래스 개수 
        super(LogReg, self).__init__()
        self.fc = nn.Linear(ft_in, nb_classes)


    def weights_init(self, m):
        if isinstance(m, nn.Linear):
            torch.nn.init.xavier_uniform_(m.weight.data)
            if m.bias is not None:
                m.bias.data.fill_(0.0)

    def forward(self, seq):
        ret = self.fc(seq)
        return ret



class LinTrans_1(nn.Module):
    def __init__(self, layers, dims): 
        super(LinTrans_1, self).__init__()
        self.layers = nn.ModuleList()  # 빈 리스트 정의 
        for i in range(layers):
            # 입력 차원과 출력 차원을 반대로 설정
            self.layers.append(nn.Linear(dims[i+1], dims[i]))  # W의 차원 순서를 변경
            
        self.dcs = SampleDecoder(act=lambda x: x)  # 이전 코드에서 설정한 활성함수 그대로

    def scale(self, z):  # 스케일링 실시 (기울기 소실 문제로 값을 작은 범위로 조정하는 것이 유리) 
        zmax = z.max(dim=1, keepdim=True)[0]
        zmin = z.min(dim=1, keepdim=True)[0]
        z_std = (z - zmin) / (zmax - zmin)
        z_scaled = z_std
        return z_scaled

    def forward(self, x):  # 순전파 
        out = x
        for layer in self.layers:
            out = layer(out)
        out = self.scale(out)
        out = F.normalize(out)
        return out

    def loss(self, x_hat, x, beta, rho):
        loss = F.mse_loss(x_hat, x) 
        return loss
